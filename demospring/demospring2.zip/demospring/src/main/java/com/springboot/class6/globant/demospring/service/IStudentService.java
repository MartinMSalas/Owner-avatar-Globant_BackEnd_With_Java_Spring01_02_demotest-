package com.springboot.class6.globant.demospring.service;

import com.springboot.class6.globant.demospring.entity.Student;

import java.util.List;

public interface IStudentService {
    public List<Student> getAllStudents();
}
