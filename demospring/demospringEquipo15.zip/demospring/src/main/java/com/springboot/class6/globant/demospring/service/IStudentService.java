package com.springboot.class6.globant.demospring.service;

import java.util.List;

public interface IStudentService {
    public List<String> getAllStudents();
}
